package rita.support;

import rita.render.RiTextBehavior;

public interface BehaviorListener
{
  public void behaviorCompleted(RiTextBehavior behavior);
}
