package test.rita;

import static org.junit.Assert.*;

import org.junit.Test;
import static test.QUnitStubs.*;

public class RiTextStaticTests
{

  @Test
  public void testDefaultFontPApplet()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDisposeRiText()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultBBoxStrokeWeight()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultBBoxStrokeFloatArray()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultBBoxStrokeFloatFloatFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultBBoxFillFloatArray()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultBBoxFillFloatFloatFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDisposeAll()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDisposeRiTextArray()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDisposeList()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testShowBoundingBoxesBoolean()
  {
    ok(false);
  }

  @Test
  public void testGetInstances()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testPickedFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testFadeAllOut()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testFadeAllIn()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testFont()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testFontPFontFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testFontPFont()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testLoadFontString()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testLoadFontStringFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testBehaviorById()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testPauseAllBehaviors()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testLoadStrings()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringFloatFloatInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletPFontStringFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringArrayFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringArrayFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringArrayFloatFloatInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletPFontStringArrayFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLettersPAppletStringIntInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLettersPAppletPFontStringIntInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletStringRectangle()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletPFontStringRectangle()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLinesPAppletPFontStringRectangleFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testSplitLetters()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testSplitLettersPFont()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testSplitChars()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringFloatFloatInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringArrayFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringArrayFloatFloatInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringArrayFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringArrayFloatFloatInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringArrayFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringRectangle()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletStringRectangleFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringRectangle()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringRectangleFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testLinesToWords()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWordsPAppletPFontStringArrayFloatFloatIntFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testRegexReplace()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testRegexMatch()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateDefaultFontStringFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateDefaultFontPAppletStringFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultBBoxVisibility()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultMouseDraggable()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultColorFloatFloatFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultColorFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultColorFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultColorFloatFloatFloat()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultAlignmentInt()
  {
    ok(false);
  }

  @Test
  public void testDefaultMotionTypeInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDrawAll()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultColorFloatArray()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateFont()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLetters()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateWords()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testCreateLines()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultAlignment()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultColor()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultFontString()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultFontStringInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultFontStringIntInt()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultFontPFont()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultFontSize()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testDefaultMotionType()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testShowBoundingBoxes()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testHeight()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testWidth()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testSize()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testRandomColor()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testBackground()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testMouse()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testLoop()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testNoLoop()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testLine()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testGraphics()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testPicked()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testTimer()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testStopTimer()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testPauseTimer()
  {
    fail("Not yet implemented");
  }

  @Test
  public void testRandom()
  {
    fail("Not yet implemented");
  }

}
