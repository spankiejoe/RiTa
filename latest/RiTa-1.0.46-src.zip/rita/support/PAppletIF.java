package rita.support;

public interface PAppletIF
{
  public String[] loadStrings(String s);
}
