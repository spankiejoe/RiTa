package test.rita;

public interface GoogleLogin
{
  String API_KEY = "AIzaSyDk9EBvYsQghuB7BBOGvGXL0pk4_SB0KTw";
  String CX_KEY = "012236010653754878383:ttpt0505nn8";
}
